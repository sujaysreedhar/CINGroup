<?php

// Option elements
require_once ELESSI_THEME_PATH . '/admin/elements/nasa_01_general_heading.php';
require_once ELESSI_THEME_PATH . '/admin/elements/nasa_02_logo_icon_heading.php';
require_once ELESSI_THEME_PATH . '/admin/elements/nasa_03_header_footer_heading.php';
require_once ELESSI_THEME_PATH . '/admin/elements/nasa_04_style_color_heading.php';
require_once ELESSI_THEME_PATH . '/admin/elements/nasa_05_type_heading.php';
require_once ELESSI_THEME_PATH . '/admin/elements/nasa_06_breadcrumb_heading.php';
require_once ELESSI_THEME_PATH . '/admin/elements/nasa_07_1_product_global_heading.php';
require_once ELESSI_THEME_PATH . '/admin/elements/nasa_07_2_product_page_heading.php';
require_once ELESSI_THEME_PATH . '/admin/elements/nasa_07_3_product_detail_heading.php';
require_once ELESSI_THEME_PATH . '/admin/elements/nasa_07_4_product_compare_heading.php';
require_once ELESSI_THEME_PATH . '/admin/elements/nasa_08_blog_heading.php';
require_once ELESSI_THEME_PATH . '/admin/elements/nasa_09_promo_popup_heading.php';
require_once ELESSI_THEME_PATH . '/admin/elements/nasa_10_portfolio_heading.php';
require_once ELESSI_THEME_PATH . '/admin/elements/nasa_11_promotion_news_heading.php';
require_once ELESSI_THEME_PATH . '/admin/elements/nasa_12_backup_options_heading.php';
