<?php
/**
 * The template for displaying the footer.
 *
 * @package nasatheme
 */

do_action('nasa_get_footer_theme');