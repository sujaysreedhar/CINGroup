Theme Name: Elessi Theme
Theme URI: http://elessi.nasatheme.com
Author: NasaTheme team
Author URI: http://nasatheme.com
Description: A Premium and Responsive WordPress theme, designed for E-Commerce websites
Tags: two-columns, three-columns, left-sidebar, right-sidebar, custom-menu, editor-style, featured-images, flexible-header, full-width-template, microformats, post-formats, rtl-language-support, sticky-post, theme-options, translation-ready, accessibility-ready
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: elessi-theme
