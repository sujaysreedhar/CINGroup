<div class="widget_shopping_wishlist_content wishlist_sidebar">
    <?php echo shortcode_exists('yith_wcwl_wishlist') ? do_shortcode('[yith_wcwl_wishlist sidebar="1"]') : '<p class="empty">' . esc_html__('Theme has not been installed or enabled Plugin Yith Wishlist.', 'elessi-theme') . '</p>'; ?>
</div>