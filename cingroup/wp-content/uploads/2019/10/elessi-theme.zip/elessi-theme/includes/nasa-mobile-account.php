<div class="content-account">
    <?php echo elessi_tiny_account(true); ?>
</div>